/*
 * Copyright (c) 2021, Texas Instruments Incorporated
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * *  Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * *  Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 *
 * *  Neither the name of Texas Instruments Incorporated nor the names of
 *    its contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO,
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
 * PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS;
 * OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR
 * OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
 * EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
#include "board.h"
volatile unsigned int delay_times = 0;
volatile bool gCheckADC;        //ADC�ɼ��ɹ���־λ
volatile uint16_t ADC_VALUE[10];
unsigned int adc_getValue(unsigned int number);//��ȡADC������
int main(void)
{
	unsigned int adc_value = 0;
    unsigned int voltage_value = 0;
    int i = 0,inc=1;
    // ϵͳ��ʼ��
    SYSCFG_DL_init();  // ��ʼ��ϵͳ����
    NVIC_ClearPendingIRQ(UART_0_INST_INT_IRQN);  // UART0�����ж�
    // ʹ�ܸ�������ж�
    NVIC_EnableIRQ(UART_0_INST_INT_IRQN); // ����UART0�ж�
	 //����DMA���˵���ʼ��ַ
    DL_DMA_setSrcAddr(DMA, DMA_CH0_CHAN_ID, (uint32_t) &ADC0->ULLMEM.MEMRES[0]);
    //����DMA���˵�Ŀ�ĵ�ַ
    DL_DMA_setDestAddr(DMA, DMA_CH0_CHAN_ID, (uint32_t) &ADC_VALUE[0]);
    //����DMA
    DL_DMA_enableChannel(DMA, DMA_CH0_CHAN_ID);
    //����ADCת��
    DL_ADC12_startConversion(ADC_VOLTAGE_INST);

    // ��ѭ��
    while (1) 
    {
		//PB2�������0V-3.3V-0V�ĵ�ѹ
		if(i==99) inc=0;
		else if(i==0) inc=1;
		if(inc) i++;
		else i--;
		DL_Timer_setCaptureCompareValue(PWM_0_INST,ABS(i*80),GPIO_PWM_0_C0_IDX);
		
		
        //��ȡADC����
        adc_value = adc_getValue(5);
        printf("adc value:%d\r\n", adc_value);
        //��ADC�ɼ������ݻ���Ϊ��ѹ
        voltage_value = (int)((adc_value/4095.0*3.3)*100);
        printf("voltage value:%d.%d%d\r\n",
        voltage_value/100,
        voltage_value/10%10,
        voltage_value%10 );
		delay_ms(200);
		LED_Flash(5);
    }
}
//��ȡADC������
unsigned int adc_getValue(unsigned int number)
{
        unsigned int gAdcResult = 0;
        unsigned char i = 0;

        //�ɼ�����ۼ�
        for( i = 0; i < number; i++ )
        {
                gAdcResult += ADC_VALUE[i];
        }
        //��ֵ�˲�
        gAdcResult /= number;

        return gAdcResult;
}





