/**
 * motor.c - ������̨ PWM ���ʵ��
 *
 * ���ļ�ֻ������β��� STEP����
 *   - ���� RPM ���� PWM ���ڣ�
 *   - ���ٶ��������� DIR��
 *   - ��ͣ STEP �����
 *   - �����/�ر� PWM �����жϹ�λ�ò�Ʋ���
 *
 * ���ļ������ġ�Ҫ�߶��ٽǶȡ����Ƕȵ������Ļ������ control.c��
 */
#include "motor.h"

volatile uint16_t Step_Period_X = 0U;
volatile uint16_t Step_Period_Y = 0U;

float Target_Speed_X = 0.0f;
float Target_Speed_Y = 0.0f;

uint16_t Motor_RpmToPeriodTicks(float abs_rpm)
{
    uint32_t period;

    if (abs_rpm < 0.5f) {
        return 0U;
    }

    period = (uint32_t)(SPEED_CONST_FACTOR /
        (abs_rpm * (float)MOTOR_STEPS_PER_REV));

    if (period < MIN_PWM_PERIOD) {
        period = MIN_PWM_PERIOD;
    }
    if (period > MAX_PWM_PERIOD) {
        period = MAX_PWM_PERIOD;
    }

    return (uint16_t)period;
}

/* �ָ� CCP ����� PWM OCTL ���ơ�ֹͣ����������ǰ����ָ��� */
static void Motor_UsePWMOutput(GPTIMER_Regs *timer)
{
    DL_TimerA_setCCPOutputDisabled(timer,
        DL_TIMER_CCP_DIS_OUT_SET_BY_OCTL, DL_TIMER_CCP_DIS_OUT_SET_BY_OCTL);
}

/* ǿ�� STEP Ϊ�͵�ƽ��ȷ��ֹͣ���ϵ�����ʱ���������塣 */
static void Motor_ForceOutputLow(GPTIMER_Regs *timer)
{
    DL_TimerA_setCCPOutputDisabled(timer,
        DL_TIMER_CCP_DIS_OUT_LOW, DL_TIMER_CCP_DIS_OUT_LOW);
}

/* д��ĳһ· PWM �����ں� 50% ռ�ձȡ� */
static void Motor_SetPWMTicks(GPTIMER_Regs *timer,
    DL_TIMER_CC_INDEX step_cc_index, uint16_t period_ticks)
{
    uint32_t load_value = (uint32_t)period_ticks - 1U;
    uint32_t duty_ticks = (uint32_t)period_ticks >> 1;

    DL_TimerA_stopCounter(timer);
    Motor_UsePWMOutput(timer);
    DL_TimerA_setLoadValue(timer, load_value);
    DL_TimerA_setTimerCount(timer, load_value);
    DL_TimerA_setCaptureCompareValue(timer, duty_ticks, step_cc_index);

    /* ��һ· CC ����Ϊ STEP ������ŵ�����ĩ���������ò���Ӱ�졣 */
    if (step_cc_index == DL_TIMER_CC_0_INDEX) {
        DL_TimerA_setCaptureCompareValue(timer, load_value, DL_TIMER_CC_1_INDEX);
    } else {
        DL_TimerA_setCaptureCompareValue(timer, load_value, DL_TIMER_CC_0_INDEX);
    }
    DL_TimerA_startCounter(timer);
}

/* ֹͣ PWM ����������ֶ�ʱ�������У�������һ���ƶ����������������ڡ� */
static void Motor_StopPWM(GPTIMER_Regs *timer, DL_TIMER_CC_INDEX step_cc_index)
{
    uint32_t load_value = STOP_PWM_PERIOD - 1U;

    DL_TimerA_stopCounter(timer);
    DL_TimerA_setLoadValue(timer, load_value);
    DL_TimerA_setTimerCount(timer, load_value);
    DL_TimerA_setCaptureCompareValue(timer, 0U, step_cc_index);
    Motor_ForceOutputLow(timer);
    DL_TimerA_startCounter(timer);
}

void Motor_EnableStepInterrupt(uint8_t axis)
{
    if (axis == GIMBAL_AXIS_X) {
        DL_TimerA_clearInterruptStatus(PWM_0_INST, DL_TIMERA_INTERRUPT_ZERO_EVENT);
        DL_TimerA_enableInterrupt(PWM_0_INST, DL_TIMERA_INTERRUPT_ZERO_EVENT);
        NVIC_ClearPendingIRQ(PWM_0_INST_INT_IRQN);
        NVIC_EnableIRQ(PWM_0_INST_INT_IRQN);
    } else if (axis == GIMBAL_AXIS_Y) {
        DL_TimerA_clearInterruptStatus(PWM_1_INST, DL_TIMERA_INTERRUPT_ZERO_EVENT);
        DL_TimerA_enableInterrupt(PWM_1_INST, DL_TIMERA_INTERRUPT_ZERO_EVENT);
        NVIC_ClearPendingIRQ(PWM_1_INST_INT_IRQN);
        NVIC_EnableIRQ(PWM_1_INST_INT_IRQN);
    }
}

void Motor_DisableStepInterrupt(uint8_t axis)
{
    if (axis == GIMBAL_AXIS_X) {
        DL_TimerA_disableInterrupt(PWM_0_INST, DL_TIMERA_INTERRUPT_ZERO_EVENT);
        DL_TimerA_clearInterruptStatus(PWM_0_INST, DL_TIMERA_INTERRUPT_ZERO_EVENT);
    } else if (axis == GIMBAL_AXIS_Y) {
        DL_TimerA_disableInterrupt(PWM_1_INST, DL_TIMERA_INTERRUPT_ZERO_EVENT);
        DL_TimerA_clearInterruptStatus(PWM_1_INST, DL_TIMERA_INTERRUPT_ZERO_EVENT);
    }
}

void Motor_StopAxis(uint8_t axis)
{
    if (axis == GIMBAL_AXIS_X) {
        Motor_DisableStepInterrupt(GIMBAL_AXIS_X);
        Step_Period_X = 0U;
        Target_Speed_X = 0.0f;
        Motor_StopPWM(GIMBAL_X_STEP_TIMER, GIMBAL_X_STEP_CC_INDEX);
        DL_GPIO_setPins(EN_PORT, EN_MA_PIN);
    } else if (axis == GIMBAL_AXIS_Y) {
        Motor_DisableStepInterrupt(GIMBAL_AXIS_Y);
        Step_Period_Y = 0U;
        Target_Speed_Y = 0.0f;
        Motor_StopPWM(GIMBAL_Y_STEP_TIMER, GIMBAL_Y_STEP_CC_INDEX);
        DL_GPIO_setPins(EN_PORT, EN_MB_PIN);
    }
}

void Motor_SetAxisSpeed_RPM(uint8_t axis, float rpm)
{
    float abs_speed;
    uint16_t new_period;

    if (rpm > SPEED_LIMIT) {
        rpm = SPEED_LIMIT;
    }
    if (rpm < -SPEED_LIMIT) {
        rpm = -SPEED_LIMIT;
    }

    abs_speed = (rpm >= 0.0f) ? rpm : -rpm;
    if (abs_speed < 0.5f) {
        Motor_StopAxis(axis);
        return;
    }

    new_period = Motor_RpmToPeriodTicks(abs_speed);

    if (axis == GIMBAL_AXIS_X) {
        if (rpm > 0.0f) {
            DL_GPIO_setPins(DIR_PORT, DIR_A_PIN);
        } else {
            DL_GPIO_clearPins(DIR_PORT, DIR_A_PIN);
        }
        DL_GPIO_setPins(EN_PORT, EN_MA_PIN);
        Motor_SetPWMTicks(GIMBAL_X_STEP_TIMER, GIMBAL_X_STEP_CC_INDEX, new_period);
        Step_Period_X = new_period;
        Target_Speed_X = rpm;
    } else if (axis == GIMBAL_AXIS_Y) {
        if (rpm > 0.0f) {
            DL_GPIO_setPins(DIR_PORT, DIR_B_PIN);
        } else {
            DL_GPIO_clearPins(DIR_PORT, DIR_B_PIN);
        }
        DL_GPIO_setPins(EN_PORT, EN_MB_PIN);
        Motor_SetPWMTicks(GIMBAL_Y_STEP_TIMER, GIMBAL_Y_STEP_CC_INDEX, new_period);
        Step_Period_Y = new_period;
        Target_Speed_Y = rpm;
    }
}

/* �����ٶȿ��ƽӿڣ�λ��ģʽ�ڲ���Ҫʹ�� Motor_SetAxisSpeed_RPM�� */
void Set_Motor_Speed_RPM(float rpm_x, float rpm_y)
{
    Motor_SetAxisSpeed_RPM(GIMBAL_AXIS_X, rpm_x);
    Motor_SetAxisSpeed_RPM(GIMBAL_AXIS_Y, rpm_y);
}