#ifndef __CONTROL_H
#define __CONTROL_H
#include "board.h"
#include <stdint.h>


#define ANGLE_PWM_K 2.7777777777f

extern float Voltage;


extern float real_arm_angle;
extern float real_base_angle;

extern float step_base;
extern float step_arm;

#endif
