#include "motor.h"


void Set_PWM(int pwma,int pwmb)
{
	DL_Timer_setCaptureCompareValue(PWM_0_INST,pwma,GPIO_PWM_0_C0_IDX);//��ҡ
	DL_Timer_setCaptureCompareValue(PWM_1_INST,pwmb,GPIO_PWM_1_C1_IDX);//��̨
}
