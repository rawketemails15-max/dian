################################################################################
# Automatically-generated file. Do not edit!
################################################################################

SHELL = cmd.exe

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../Hardware/board.c \
../Hardware/key.c \
../Hardware/motor.c 

C_DEPS += \
./Hardware/board.d \
./Hardware/key.d \
./Hardware/motor.d 

OBJS += \
./Hardware/board.o \
./Hardware/key.o \
./Hardware/motor.o 

OBJS__QUOTED += \
"Hardware\board.o" \
"Hardware\key.o" \
"Hardware\motor.o" 

C_DEPS__QUOTED += \
"Hardware\board.d" \
"Hardware\key.d" \
"Hardware\motor.d" 

C_SRCS__QUOTED += \
"../Hardware/board.c" \
"../Hardware/key.c" \
"../Hardware/motor.c" 


