#include "motor.h"


void Set_PWM(int pwma,int pwmb)
{
    Position1 = pwma;
	Position2 = pwmb;
	DL_Timer_setCaptureCompareValue(PWM_0_INST,Position1,GPIO_PWM_0_C0_IDX);//��ҡ
	DL_Timer_setCaptureCompareValue(PWM_1_INST,Position2,GPIO_PWM_1_C1_IDX);//��̨
}
