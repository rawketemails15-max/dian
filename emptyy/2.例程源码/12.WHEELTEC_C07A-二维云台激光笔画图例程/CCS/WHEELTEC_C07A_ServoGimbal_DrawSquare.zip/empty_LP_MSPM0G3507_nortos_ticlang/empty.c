/*
 * Copyright (c) 2021, Texas Instruments Incorporated
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * *  Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * *  Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 *
 * *  Neither the name of Texas Instruments Incorporated nor the names of
 *    its contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO,
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
 * PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS;
 * OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR
 * OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
 * EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
#include "board.h"
#include "stdio.h"
#include "key.h"
#include "motor.h"
int32_t PWMA,PWMB;
float Position1=750,Position2=750,Target1=750,Target2=750; 
int loop_flag=0;
int main(void)
{
	SYSCFG_DL_init();
    DL_Timer_startCounter(PWM_0_INST);//����PWM���
	DL_Timer_startCounter(PWM_1_INST);//����PWM���
	NVIC_ClearPendingIRQ(UART_0_INST_INT_IRQN);//����жϱ�־λ
	NVIC_ClearPendingIRQ(TIMER_0_INST_INT_IRQN);
//	//ʹ�ܴ����ж�
	NVIC_EnableIRQ(UART_0_INST_INT_IRQN);//�����ж�
	NVIC_EnableIRQ(TIMER_0_INST_INT_IRQN);
    while (1) 
    {
		printf("%.2f\t%.2f\t%d\r\n",Target1,Target2,loop_flag);
		delay_ms(100);
    }
}
//pb17����̨��PB16�ӱ�ҡ
void TIMER_0_INST_IRQHandler(void)
{
	if(DL_TimerA_getPendingInterrupt(TIMER_0_INST))
	{
		if(DL_TIMER_IIDX_ZERO)
		{
			if(click()) loop_flag=1;
			if(loop_flag == 1)  Target1=Target1+1;
			if(loop_flag == 2)  Target2=Target2-1;			
			if(loop_flag == 3)  Target1=Target1-1;			
			if(loop_flag == 4)  Target2=Target2+1;								
			if(loop_flag == 5)  Target1=Target1+1;						
			if(loop_flag == 6)  Target2=Target2-1;			
			if((Target1 == 771)&&(Target2 == 750)) loop_flag=2;	
			else  if((Target1 == 771)&&(Target2 == 730)) loop_flag=3;
			else  if((Target1 == 720)&&(Target2 == 730)) loop_flag=4;
			else  if((Target1 == 720)&&(Target2 == 778)) loop_flag=5;		
			else  if((Target1 == 771)&&(Target2 == 778)) loop_flag=6;	
			PWMA = Target1;//��ҡ
			PWMB = Target2;//��̨
			Set_PWM(PWMA,PWMB);
		}   
	}
}











