/*
 * Copyright (c) 2021, Texas Instruments Incorporated
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * *  Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * *  Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 *
 * *  Neither the name of Texas Instruments Incorporated nor the names of
 *    its contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO,
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
 * PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS;
 * OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR
 * OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
 * EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
#include "board.h"
#include "stdio.h"
#include "K210.h"
#include "oled.h"
#include "key.h"
uint8_t send_k210_flag = 0;//�������ݵ�k210�ı�־λ
uint8_t seltec_vaule = 0;//��ɫѡ��:0�� 1�� 2�� 3��

int main(void)
{
	SYSCFG_DL_init();
	NVIC_ClearPendingIRQ(UART_0_INST_INT_IRQN);
	NVIC_ClearPendingIRQ(UART_1_INST_INT_IRQN);
	//ʹ�ܴ����ж�
	NVIC_EnableIRQ(UART_1_INST_INT_IRQN);
	OLED_Init();
    while (1) 
    {
		if(key_scan(75)==USEKEY_single_click){send_k210_flag=1;seltec_vaule++;seltec_vaule%=4;}//����ɨ�裬�����л�ʶ�����ɫ
		// //�����ѡ��ɫ������demo��ʹ��,����demo��ʹ�øù���
		if( send_k210_flag==1 )//���ڰ���ɨ���д�������������BLS���л���ɫ
		{
			send_k210_flag = 0;
			for(uint8_t i=0;i<2;i++)
				update_sendmsg_and_Send(seltec_vaule);//����ѡ�������ɫ���и��ٵ�k210
		}
		memset(OLED_GRAM,0, 128*8*sizeof(uint8_t)); //GRAM���㵫������ˢ�£���ֹ����
		OLED_ShowString(0,0,"ShowNum:");
		OLED_ShowNumber(80,0,show_num,1,12);
		OLED_ShowString(0,10,"Fllo_Color:");
		switch(seltec_vaule)
		{
			case 0:OLED_ShowString(90,10,"Blue  ");
				break;             
			case 1:OLED_ShowString(90,10,"Green ");
				break;             
			case 2:OLED_ShowString(90,10,"Yellow");
				break;             
			case 3:OLED_ShowString(90,10,"Red   ");
				break;
			default:
				break;
		}
		OLED_ShowString(0,20,"FollowX:");
		OLED_ShowNumber(70,20,ObjectTrack.centerX,4,12);
		OLED_ShowString(0,30,"FollowY:");
		OLED_ShowNumber(70,30,ObjectTrack.centerY,4,12);
		OLED_ShowString(0,40,"CamX:");
		OLED_ShowNumber(70,40,ObjectTrack.cam_centerX,4,12);
		OLED_ShowString(0,50,"CamY:");
		OLED_ShowNumber(70,50,ObjectTrack.cam_centerY,4,12);

		OLED_Refresh_Gram();
    }
}








