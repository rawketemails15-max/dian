/*
 * Copyright (c) 2021, Texas Instruments Incorporated
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * *  Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * *  Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 *
 * *  Neither the name of Texas Instruments Incorporated nor the names of
 *    its contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO,
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
 * PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS;
 * OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR
 * OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
 * EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
#include "board.h"
#include "led.h"


int main(void)
{
    SYSCFG_DL_init();
    NVIC_ClearPendingIRQ(UART_0_INST_INT_IRQN);
    NVIC_EnableIRQ(UART_0_INST_INT_IRQN);
    uint32_t start_time, end_time, echo_time;
    uint32_t timeout_counter;
    float distance;
    
    printf("HC-SR04 Distance Measurement Start\r\n");
    
    while (1) 
    {
        // 1. ���ʹ�������
        DL_GPIO_setPins(HCSR04_PORT, HCSR04_Trig_PIN);    // Trig��Ϊ�ߵ�ƽ
        delay_us(12);                                       // ��ʱ12us
        DL_GPIO_clearPins(HCSR04_PORT, HCSR04_Trig_PIN);  // Trig��Ϊ�͵�ƽ
        
        // 2. �ȴ�Echo���ű�Ϊ�ߵ�ƽ
        timeout_counter = 0;
        while(DL_GPIO_readPins(HCSR04_PORT, HCSR04_Echo_PIN) == 0)
        {
            delay_us(1);
            timeout_counter++;
            if(timeout_counter > 30000) // 30ms��ʱ
            {
                printf("Echo timeout - no response\r\n");
                break;
            }
        }
        // ֻ����û�г�ʱ������²ż�������
        if(timeout_counter <= 30000)
        {
            // 3. ��¼�ߵ�ƽ��ʼʱ��
            start_time = Systick_getTick();
            
            // 4. �ȴ�Echo���ű�Ϊ�͵�ƽ
            timeout_counter = 0;
            while(DL_GPIO_readPins(HCSR04_PORT, HCSR04_Echo_PIN) != 0)
            {
                delay_us(1);
                timeout_counter++;
                if(timeout_counter > 30000) // 30ms��ʱ
                {
                    printf("Echo timeout - too long\r\n");
                    break;
                }
            }
            // ֻ����û�г�ʱ������²ż������
            if(timeout_counter <= 30000)
            {
                // 5. ��¼�ߵ�ƽ����ʱ��
                end_time = Systick_getTick();
                
                // 6. ����ߵ�ƽ����ʱ��
                if(end_time <= start_time)
                {
                    echo_time = start_time - end_time;
                }
                else
                {
                    echo_time = start_time + (SysTickMAX_COUNT - end_time);
                }
                
                // 7. ת��Ϊ΢�루��Ҫ�������SysTickƵ�ʵ�����
                echo_time = echo_time / (SysTickFre / 1000000);
                // 8. ������루���ף�
                // ���� = (ʱ�� * ����) / 2������Լ34000cm/s
                distance = (float)echo_time * 34000.0 / 2000000.0;
                // 9. ������
                if(distance > 2.0 && distance < 400.0) // ��Ч��Χ
                {
                    printf("Distance: %.2f cm (Echo time: %lu us)\r\n", distance, echo_time);
                }
                else
                {
                    printf("Out of range: %.2f cm\r\n", distance);
                }
            }
        }
        // LED��˸ָʾ
        LED_Flash(2);
        // ��ʱ500ms�ٽ�����һ�β���
        delay_ms(500);
    }
}









