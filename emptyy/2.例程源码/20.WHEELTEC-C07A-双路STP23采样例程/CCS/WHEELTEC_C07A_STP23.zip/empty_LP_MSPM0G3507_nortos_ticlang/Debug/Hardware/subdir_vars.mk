################################################################################
# Automatically-generated file. Do not edit!
################################################################################

SHELL = cmd.exe

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../Hardware/STP23.c \
../Hardware/board.c 

C_DEPS += \
./Hardware/STP23.d \
./Hardware/board.d 

OBJS += \
./Hardware/STP23.o \
./Hardware/board.o 

OBJS__QUOTED += \
"Hardware\STP23.o" \
"Hardware\board.o" 

C_DEPS__QUOTED += \
"Hardware\STP23.d" \
"Hardware\board.d" 

C_SRCS__QUOTED += \
"../Hardware/STP23.c" \
"../Hardware/board.c" 


