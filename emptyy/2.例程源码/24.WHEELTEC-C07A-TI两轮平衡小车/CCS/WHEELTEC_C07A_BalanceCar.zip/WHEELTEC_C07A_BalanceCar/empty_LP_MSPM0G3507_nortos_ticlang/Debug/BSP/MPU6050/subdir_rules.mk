################################################################################
# Automatically-generated file. Do not edit!
################################################################################

SHELL = cmd.exe

# Each subdirectory must supply rules for building sources it contributes
BSP/MPU6050/%.o: ../BSP/MPU6050/%.c $(GEN_OPTS) | $(GEN_FILES) $(GEN_MISC_FILES)
	@echo 'Building file: "$<"'
	@echo 'Invoking: Arm Compiler'
	"D:/ti/ccs2020/ccs/tools/compiler/ti-cgt-armllvm_4.0.3.LTS/bin/tiarmclang.exe" -c @"device.opt"  -march=thumbv6m -mcpu=cortex-m0plus -mfloat-abi=soft -mlittle-endian -mthumb -O0 -I"C:/Users/Mayn/Desktop/CCS/WHEELTEC_C07A_BalanceCar/WHEELTEC_C07A_BalanceCar/empty_LP_MSPM0G3507_nortos_ticlang/BSP/MPU6050" -I"C:/Users/Mayn/Desktop/CCS/WHEELTEC_C07A_BalanceCar/WHEELTEC_C07A_BalanceCar/empty_LP_MSPM0G3507_nortos_ticlang/BSP/MPU6050/DMP" -I"C:/Users/Mayn/Desktop/CCS/WHEELTEC_C07A_BalanceCar/WHEELTEC_C07A_BalanceCar/empty_LP_MSPM0G3507_nortos_ticlang/WHEELTEC_APP/Inc" -I"C:/Users/Mayn/Desktop/CCS/WHEELTEC_C07A_BalanceCar/WHEELTEC_C07A_BalanceCar/empty_LP_MSPM0G3507_nortos_ticlang/BSP/Inc" -I"C:/Users/Mayn/Desktop/CCS/WHEELTEC_C07A_BalanceCar/WHEELTEC_C07A_BalanceCar/empty_LP_MSPM0G3507_nortos_ticlang" -I"C:/Users/Mayn/Desktop/CCS/WHEELTEC_C07A_BalanceCar/WHEELTEC_C07A_BalanceCar/empty_LP_MSPM0G3507_nortos_ticlang/Debug" -I"D:/ti/mspm0_sdk_2_01_00_03/source/third_party/CMSIS/Core/Include" -I"D:/ti/mspm0_sdk_2_01_00_03/source" -gdwarf-3 -MMD -MP -MF"BSP/MPU6050/$(basename $(<F)).d_raw" -MT"$(@)"  $(GEN_OPTS__FLAG) -o"$@" "$<"
	@echo 'Finished building: "$<"'
	@echo ' '


