################################################################################
# Automatically-generated file. Do not edit!
################################################################################

SHELL = cmd.exe

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../Hardware/K210.c \
../Hardware/board.c \
../Hardware/bsp_key.c \
../Hardware/motor.c \
../Hardware/oled.c 

C_DEPS += \
./Hardware/K210.d \
./Hardware/board.d \
./Hardware/bsp_key.d \
./Hardware/motor.d \
./Hardware/oled.d 

OBJS += \
./Hardware/K210.o \
./Hardware/board.o \
./Hardware/bsp_key.o \
./Hardware/motor.o \
./Hardware/oled.o 

OBJS__QUOTED += \
"Hardware\K210.o" \
"Hardware\board.o" \
"Hardware\bsp_key.o" \
"Hardware\motor.o" \
"Hardware\oled.o" 

C_DEPS__QUOTED += \
"Hardware\K210.d" \
"Hardware\board.d" \
"Hardware\bsp_key.d" \
"Hardware\motor.d" \
"Hardware\oled.d" 

C_SRCS__QUOTED += \
"../Hardware/K210.c" \
"../Hardware/board.c" \
"../Hardware/bsp_key.c" \
"../Hardware/motor.c" \
"../Hardware/oled.c" 


