#ifndef	__BOARD_H__
#define __BOARD_H__

#include "ti_msp_dl_config.h"
#include "math.h"

#define ABS(a)      (a>0 ? a:(-a))



extern int32_t Get_Encoder_countA,Get_Encoder_countB;


#define SysTickMAX_COUNT 0xFFFFFF


#define SysTickFre 80000000


#define SysTick_MS(x)  ((SysTickFre/1000U)*(uint32_t)(x))
#define SysTick_US(x)  ((SysTickFre/1000000U)*(uint32_t)(x))
uint32_t Systick_getTick(void);
void delay_us(uint32_t us);
void delay_ms(uint32_t ms);
void delay_1us(unsigned long __us);
void delay_1ms(unsigned long ms);

void uart0_send_char(char ch);
void uart0_send_string(char* str);
uint8_t TTL_Hex2Dec(void);


int target_limit_int(int insert,int low,int high);
float target_limit_float(float insert,float low,float high);
int servo_speed_control(int speed);
int Angle_to_PWM(float Angle);
int voltage_to_percentage(float voltage);
void AppSendData(char* buffer,uint8_t Len);

extern uint16_t TestAPP_Param1 ;
extern uint16_t TestAPP_Param2 ;

typedef struct {
    double kp; // ��������
    double ki; // ��������
    double kd; // ΢������
    double setpoint; // �趨��
    double integral; // ������
    double last_error; // ��һ�ε����
    double last_input; // ��һ�ε�����
} PIDController;
double PID_Update(PIDController *pid, double target , double input);
void PID_Init(PIDController *pid, double kp, double ki, double kd);





#endif
