/*
 * Copyright (c) 2021, Texas Instruments Incorporated
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * *  Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * *  Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 *
 * *  Neither the name of Texas Instruments Incorporated nor the names of
 *    its contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO,
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
 * PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS;
 * OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR
 * OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
 * EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
#include "board.h"
#include "stdio.h"
#include "K210.h"
#include "oled.h"
#include "bsp_key.h"
#include "motor.h"
uint8_t send_k210_flag = 0;//�������ݵ�k210�ı�־λ
uint8_t seltec_vaule = 0;//��ɫѡ��:0�� 1�� 2�� 3��
//������ֵ,����ͨ��APP��ʾ���޸�
uint16_t TestAPP_Param1 = 100;
uint16_t TestAPP_Param2 = 400;

PIDController FollowPID_X,FollowPID_Y;

static int servopwm = 1500;

static short mycontrol = 0;
int Servo_PWM=1500;

int main(void)
{
	SYSCFG_DL_init();
	DL_Timer_startCounter(PWM_0_INST);//    PWM   
	DL_Timer_startCounter(PWM_1_INST);//    PWM   
	NVIC_ClearPendingIRQ(UART_0_INST_INT_IRQN);
	NVIC_ClearPendingIRQ(UART_1_INST_INT_IRQN);
	NVIC_ClearPendingIRQ(UART_2_INST_INT_IRQN);
	//ʹ�ܴ����ж�
	NVIC_EnableIRQ(UART_1_INST_INT_IRQN);
	NVIC_EnableIRQ(UART_2_INST_INT_IRQN);
	NVIC_ClearPendingIRQ(TIMER_0_INST_INT_IRQN);  
    NVIC_EnableIRQ(TIMER_0_INST_INT_IRQN);        
	OLED_Init();
	PID_Init(&FollowPID_X,1.2,0,12);//PID��������ʼ��
	PID_Init(&FollowPID_Y,-0.024,-0,-0.04);//PID��������ʼ��
	
    while (1) 
    {
		//��ʾAB����Լ������Ŀ��ֵ��ʵ��ֵ
		OLED_ShowFloat(0,0,ObjectTrack.cam_centerX,4,2);
		OLED_ShowFloat(0,10,ObjectTrack.cam_centerY,4,2);
		
		OLED_ShowFloat(0,30,ObjectTrack.centerX,4,2);//ˮƽ
		OLED_ShowFloat(0,40,ObjectTrack.centerY,4,2);
		
		OLED_ShowFloat(0,50,mycontrol,4,12);
		OLED_Refresh_Gram();
    }
}


void TIMER_0_INST_IRQHandler(void)
{
	static uint32_t LedTickCnt = 0;
	static uint32_t adc_taskCnt = 0;
	static uint8_t EncoderTaskFlag = 0;
	
	static uint32_t mode = 0;
	
	uint32_t ticktime = 0;
    if(DL_TimerA_getPendingInterrupt(TIMER_0_INST))
    {
        if(DL_TIMER_IIDX_ZERO)
        {
		pKeyInterface_t key = &UserKey;
		UserKeyState_t keystate = key->getKeyState(200);
		if( keystate == USEKEY_long_click )
		{
			//k210
			mode=1;
		}
		else if( keystate == USEKEY_single_click )
		{
			//��
			mode=2;
		}
		else if( keystate == USEKEY_double_click )
		{
			//��
			mode=3;
		}
		
		if( mode==1 )
		{
			mycontrol = PID_Update(&FollowPID_X,ObjectTrack.cam_centerX,ObjectTrack.centerX);
		}
		else if( mode==2 )
		{
			mycontrol = 100;
		}
		else if( mode==3 )
		{
			mycontrol = -100;
		}
//		target_angle = PID_Update(&FollowPID_Y,ObjectTrack.cam_centerY,ObjectTrack.centerY);
//		
//		//�������,�޷�Ŀ��ֵ
//		#if _180_SERVO
//		target_angle = target_limit_float(target_angle,0,180);
//		#endif
//		
//		#if _270_SERVO
//		target_angle = target_limit_float(target_angle,0,270);
//		#endif
		
		//���PWM�޷�
		mycontrol = target_limit_int(mycontrol,-400,400);
		
		//������ƣ���Ŀ��Ƕ�ת��ΪPWM����ֵ
//		Servo_PWM = Angle_to_PWM(target_angle);
		Servo_PWM=servo_speed_control(mycontrol);
		Set_PWM(1500,Servo_PWM);
		}
	}
}


int servo_speed_control(int speed) {
    /*
     * �������ٶ�(-350 to 350)ӳ�䵽���PWMֵ(1000 to 2000)����������
     * speed: �����ٶ�ֵ��-350(�����ʱ��) �� 350(���˳ʱ��)��0Ϊֹͣ
     * ����: �ٶ�-50��50��ӦPWM=1500��ֹͣ��
     * ����: ��Ӧ��PWMֵ(1000-2000)
     */
    
    // �������뷶Χ
    if (speed > 400) speed = 400;
    if (speed < -400) speed = -400;
    
	int pwm = 0;
	
	if( speed > 0 )
		pwm = 1600 + speed;
	else if( speed < 0 )
		pwm = 1400 + speed;
    else pwm = 1500;
	
    return pwm;
}

//����Ƕ�ת��ΪPWM����
int Angle_to_PWM(float Angle)
{
	//PWM 500~2500 ��Ӧռ�ձ� 2.5%~12.5%����Ӧ��� 0-180��
	
	#if _180_SERVO
	// 180�ȶ���Ƕ�ת��
    if (Angle < 0.0f) Angle = 0.0f;
    if (Angle > 180.0f) Angle = 180.0f;
    
    // ����ӳ�䣺PWM = 500 + (2500-500)*Angle/180
    // �򻯺�PWM = 500 + 2000*Angle/180
    int PWM = (int)(500 + (2000.0f * Angle / 180.0f));
    
    // ȷ��PWMֵ����Ч��Χ��
    if (PWM < 500) PWM = 500;
    if (PWM > 2500) PWM = 2500;
    
    return PWM;
	#endif
	
	//�����270�ȶ������ʹ����������
	#if _270_SERVO
	// ���ƽǶȷ�Χ��0~270��
    if (Angle < 0.0f) Angle = 0.0f;
    if (Angle > 270.0f) Angle = 270.0f;
    
    // ����ӳ�䣺PWM = 500 + (2500-500)*Angle/270
    // �򻯺�PWM = 500 + 2000*Angle/270
    int PWM = (int)(500 + (2000.0f * Angle / 270.0f));
    
    // ȷ��PWMֵ����Ч��Χ��
    if (PWM < 500) PWM = 500;
    if (PWM > 2500) PWM = 2500;
    
    return PWM;
	#endif
}


int target_limit_int(int insert,int low,int high)
{
    if (insert < low)
        return low;
    else if (insert > high)
        return high;
    else
        return insert;	
}

float target_limit_float(float insert,float low,float high)
{
    if (insert < low)
        return low;
    else if (insert > high)
        return high;
    else
        return insert;	
}



PIDController FollowPID_X,FollowPID_Y;

void PID_Init(PIDController *pid, double kp, double ki, double kd) {
    pid->kp = kp;
    pid->ki = ki;
    pid->kd = kd;
    pid->setpoint = 0;
    pid->integral = 0.0;
    pid->last_error = 0.0;
    pid->last_input = 0.0;
}

double PID_Update(PIDController *pid, double target , double input)
{	
	pid->setpoint = target;
	
    double error = pid->setpoint - input;//����ƫ��
	double derivative = (input - pid->last_input);//��һ��ƫ��
	
    pid->integral += error;//����
	
    // ����PID���
    double output = pid->kp * error + pid->ki * pid->integral - pid->kd * derivative;

    // ������һ�ε���������
    pid->last_error = error;
    pid->last_input = input;

    return output;
}







