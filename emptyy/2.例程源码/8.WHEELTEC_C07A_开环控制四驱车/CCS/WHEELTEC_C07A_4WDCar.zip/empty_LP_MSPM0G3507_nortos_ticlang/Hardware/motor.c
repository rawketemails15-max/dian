#include "motor.h"
float Velcity_Kp=1.00,  Velcity_Ki=0.5,  Velcity_Kd; //����ٶ�PID����
/***********************************************
��˾����Ȥ�Ƽ�����ݸ�����޹�˾
Ʒ�ƣ�WHEELTEC
������wheeltec.net
�Ա����̣�shop114407458.taobao.com 
����ͨ: https://minibalance.aliexpress.com/store/4455017
�汾��V1.0
�޸�ʱ�䣺2024-07-019

Brand: WHEELTEC
Website: wheeltec.net
Taobao shop: shop114407458.taobao.com 
Aliexpress: https://minibalance.aliexpress.com/store/4455017
Version: V1.0
Update��2024-07-019

All rights reserved
***********************************************/
void Set_PWM(int pwmA,int pwmB,int pwmC,int pwmD)
{
	 if(pwmA>0)
    {
        DL_GPIO_setPins(AIN_PORT,AIN_AIN2_PIN);
        DL_GPIO_clearPins(AIN_PORT,AIN_AIN1_PIN);
		DL_Timer_setCaptureCompareValue(PWM_0_INST,ABS(pwmA),GPIO_PWM_0_C0_IDX);
       
    }
    else
    {
        DL_GPIO_setPins(AIN_PORT,AIN_AIN1_PIN);
        DL_GPIO_clearPins(AIN_PORT,AIN_AIN2_PIN);
		DL_Timer_setCaptureCompareValue(PWM_0_INST,ABS(pwmA),GPIO_PWM_0_C0_IDX);
    }
	
	
    if(pwmB>0)
    {
		DL_GPIO_setPins(BIN_PORT,BIN_BIN2_PIN);
        DL_GPIO_clearPins(BIN_PORT,BIN_BIN1_PIN);
        DL_Timer_setCaptureCompareValue(PWM_0_INST,ABS(pwmB),GPIO_PWM_0_C1_IDX);
    }
    else
    {
		DL_GPIO_setPins(BIN_PORT,BIN_BIN1_PIN);
        DL_GPIO_clearPins(BIN_PORT,BIN_BIN2_PIN);
		DL_Timer_setCaptureCompareValue(PWM_0_INST,ABS(pwmB),GPIO_PWM_0_C1_IDX);
    }
	
     if(pwmC>0)
    {
		DL_GPIO_setPins(CIN_PORT,CIN_CIN2_PIN);
        DL_GPIO_clearPins(CIN_PORT,CIN_CIN1_PIN);
		DL_Timer_setCaptureCompareValue(PWM_1_INST,ABS(pwmC),GPIO_PWM_1_C0_IDX);
    }
    else
    {
		DL_GPIO_setPins(CIN_PORT,CIN_CIN1_PIN);
        DL_GPIO_clearPins(CIN_PORT,CIN_CIN2_PIN);
		DL_Timer_setCaptureCompareValue(PWM_1_INST,ABS(pwmC),GPIO_PWM_1_C0_IDX);
    }
	
	  if(pwmD>0)
    {
		DL_GPIO_setPins(DIN_PORT,DIN_DIN2_PIN);
        DL_GPIO_clearPins(DIN_PORT,DIN_DIN1_PIN);
		DL_Timer_setCaptureCompareValue(PWM_1_INST,ABS(pwmD),GPIO_PWM_1_C1_IDX);
    }
    else
    {
		DL_GPIO_setPins(DIN_PORT,DIN_DIN1_PIN);
        DL_GPIO_clearPins(DIN_PORT,DIN_DIN2_PIN);
		DL_Timer_setCaptureCompareValue(PWM_1_INST,ABS(pwmD),GPIO_PWM_1_C1_IDX);
    }

}



